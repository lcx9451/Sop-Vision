@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" "%~dp0app\1.0.0\SopVision.exe"
